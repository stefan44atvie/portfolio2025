<?php
// components/config/project_mapping.php

return [
    'Portfolio 2025' => [
        'dirname' => '/var/www/html/portfolio2025',
        'version_table' => 'portfolio_settings',
        'version_id' => 1,
    ],
];