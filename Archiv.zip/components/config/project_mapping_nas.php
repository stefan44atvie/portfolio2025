<?php
// components/config/project_mapping.php

return [
    'Agency 2025' => [
        'dirname' => '/volume1/web/agency2025',
        'version_table' => 'settings',
        'version_id' => 1,
    ],
];